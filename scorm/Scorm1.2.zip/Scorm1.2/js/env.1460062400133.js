angular.module("app-env", [])

.constant("title", "swingset - DEV")

;